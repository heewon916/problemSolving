# 관통 - 냠냠코치

담당자: 김희원, 송재민

분류: BACKEND

수식: 2025년 9월 26일 오후 4:31

# 프로젝트 소개

- 식단 분석을 활용한 개인 맞춤형 건강 코칭 서비스
- 식품의약품안전처에서 제공한 음식 별 영양 성분 데이터를 활용하여 작성한 식단을 사용자가 원하는 목표(운동, 질병 등)에 따라 분석하여 정보를 제공
- 개발언어 및 툴
    - Java, STS, HTML, CSS, JavaScript, VScode, Tomcat
- 필수 라이브러리 / 오픈소스
    - BootStrap Framework

---

# 구현 기능 - 전체적인 실행 흐름

### MainController.java

![image.png](img/image.png)

---

# 구현 기능 - 코드 및 실행화면

| 난이도 | 구현 기능 | 점수  | 비고 | 완료 [✅] |
| --- | --- | --- | --- | --- |
| 기본  | 식단기록 관리 기능  | 30 | 화면, 등록, 조회, 수정, 삭제 기능  | ✅ |
| 기본 | 회원정보 관리 기능  | 30 | 화면, 등록, 조회, 수정, 삭제 기능  | ✅ |

## ✅기본 기능 (1) - 식단 기록 관리 기능

- 식단 기록 관리 기능(작성, 조회, 수정, 삭제)을 위한 MVC 아키텍처 설계 및 코드 작성 (Controller/Service/Dao/DTO/JSP)

### 📌1. 로그인 후 화면  ➡️ 내 식단 보러 가기 click

![image.png](img/image%201.png)

### 📌2. 내 식단 기록 ➡️ 식단 추가하기 click

![image.png](img/image%202.png)

![image.png](img/image%203.png)

### 📌3. 식단 추가 완료 화면

![image.png](img/image%204.png)

### 📌4. 식단 상세 정보 화면

![image.png](img/image%205.png)

![image.png](img/image%206.png)

### 📌5. 식단 수정 화면 ➡️ 섭취량:52g ⇒ 섭취량: 152g

![image.png](img/image%207.png)

![image.png](img/image%208.png)

![image.png](img/image%209.png)

### 📌6. 삭제 클릭 시, alert 메시지

![image.png](img/image%2010.png)

![image.png](img/image%2011.png)

### 📌7. 식단 점수 화면

![image.png](img/image%2012.png)

![image.png](img/image%2013.png)

---

## ✅기본 기능 (2) - 회원 정보 관리 기능

- 회원 정보 관리 기능(작성, 조회, 수정, 삭제)을 위한 MVC 아키텍처 설계 및 코드 작성 (Controller/Service/Dao/DTO/JSP)
- 사용자 프로필 (키, 몸무게, 질환 등) 관리 기능 구현
- 로그인/로그아웃 기능 구현

### 📌1. 로그인 기능

### 📌2. 로그아웃 기능

![image.png](img/image%2014.png)

![image.png](img/image%2015.png)

![image.png](img/image%2016.png)

### 📌3. 회원가입 기능

![image.png](img/image%2017.png)

![image.png](img/image%2018.png)

### ➡️ 로그인 직후 화면

![image.png](img/image%2019.png)

### 📌4. 사용자 프로필 관리 기능

![image.png](img/image%2020.png)

![image.png](img/image%2021.png)

![image.png](img/image%2022.png)