package com.ssafy.exam.model.service;

import com.ssafy.exam.model.dto.DietRecord;
import com.ssafy.exam.model.dto.Food;

import java.util.List;

public interface DietRecordService {
    List<DietRecord> getDietRecords(String userId);
    DietRecord getDietRecordById(int recordId);
    void addDietRecord(DietRecord dietRecord);
    void modifyDietRecord(DietRecord dietRecord);
    void removeDietRecord(int recordId);
    List<Food> getAllFoods();

    /**
     * 식단 분석 점수를 계산하는 메서드
     * @param userId 사용자 ID
     * @return 분석 점수
     */
    double calculateDietScore(String userId);
}
