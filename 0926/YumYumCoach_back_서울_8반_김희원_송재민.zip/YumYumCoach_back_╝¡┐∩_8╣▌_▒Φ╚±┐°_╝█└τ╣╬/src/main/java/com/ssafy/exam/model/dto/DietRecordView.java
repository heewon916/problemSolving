package com.ssafy.exam.model.dto;

import java.util.Date;

/**
 * View 레이어로 식단 정보를 전달하기 위한 클래스 (VO or ViewModel)
 */
public class DietRecordView {
    private int recordId;
    private String userId;
    private int foodCode;
    private String foodName; // 음식 이름 추가
    private int intake;
    private Date recordDate;

    public DietRecordView(DietRecord dietRecord, String foodName) {
        this.recordId = dietRecord.getRecordId();
        this.userId = dietRecord.getUserId();
        this.foodCode = dietRecord.getFoodCode();
        this.intake = dietRecord.getIntake();
        this.recordDate = dietRecord.getRecordDate();
        this.foodName = foodName;
    }

    // Getters
    public int getRecordId() { return recordId; }
    public String getUserId() { return userId; }
    public int getFoodCode() { return foodCode; }
    public String getFoodName() { return foodName; }
    public int getIntake() { return intake; }
    public Date getRecordDate() { return recordDate; }
}
