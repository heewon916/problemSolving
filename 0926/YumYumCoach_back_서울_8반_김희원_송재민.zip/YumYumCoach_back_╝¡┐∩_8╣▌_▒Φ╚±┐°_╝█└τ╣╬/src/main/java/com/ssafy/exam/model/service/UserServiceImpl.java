package com.ssafy.exam.model.service;

import com.ssafy.exam.model.dao.CoachDao;
import com.ssafy.exam.model.dao.FileCoachDao;
import com.ssafy.exam.model.dto.User;

import java.util.List;

public class UserServiceImpl implements UserService {

    private final CoachDao coachDao = FileCoachDao.getInstance();
    private static final UserServiceImpl instance = new UserServiceImpl();

    private UserServiceImpl() {}

    public static UserServiceImpl getInstance() {
        return instance;
    }

    @Override
    public List<User> getAllUsers() {
        return coachDao.selectAllUsers();
    }

    @Override
    public User getUserById(String userId) {
        return coachDao.selectUserById(userId);
    }

    @Override
    public void join(User user) {
        // ID 중복 체크 등의 비즈니스 로직 추가 가능
        if (coachDao.selectUserById(user.getId()) != null) {
            throw new IllegalArgumentException("이미 존재하는 아이디입니다.");
        }
        coachDao.insertUser(user);
    }

    @Override
    public void modifyUser(User user) {
        // 수정 전 사용자 존재 여부 확인 등의 로직 추가 가능
        if (coachDao.selectUserById(user.getId()) == null) {
            throw new IllegalArgumentException("존재하지 않는 사용자입니다.");
        }
        coachDao.updateUser(user);
    }

    @Override
    public void removeUser(String userId) {
        coachDao.deleteUser(userId);
    }

    @Override
    public User login(String userId, String password) {
        User user = coachDao.login(userId, password);
        // 로그인 실패 시 예외 처리 또는 null 반환
        if (user == null) {
            // 로그인 실패 관련 로직 (e.g., 시도 횟수 증가) 추가 가능
        }
        return user;
    }
}
