package com.ssafy.exam.listener;

import com.ssafy.exam.model.dao.FileCoachDao;
import jakarta.servlet.ServletContextEvent;
import jakarta.servlet.ServletContextListener;
import jakarta.servlet.annotation.WebListener;

@WebListener
public class CoachContextListener implements ServletContextListener {

    @Override
    public void contextInitialized(ServletContextEvent sce) {
        System.out.println("Nyam Nyam Coach contextInitialized() called");
        FileCoachDao.getInstance().load();
    }

    @Override
    public void contextDestroyed(ServletContextEvent sce) {
        System.out.println("Nyam Nyam Coach contextDestroyed() called");
        FileCoachDao.getInstance().save();
    }
}
