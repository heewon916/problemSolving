package com.ssafy.exam.model.dto;

import java.io.Serializable;
import java.util.Date;

public class DietRecord implements Serializable {
    private static final long serialVersionUID = 1L;

    private int recordId; // 식단 기록 ID
    private String userId; // 사용자 ID
    private int foodCode; // 음식 코드
    private int intake; // 섭취량 (g)
    private Date recordDate; // 기록 날짜

    public DietRecord() {}

    public DietRecord(int recordId, String userId, int foodCode, int intake, Date recordDate) {
        this.recordId = recordId;
        this.userId = userId;
        this.foodCode = foodCode;
        this.intake = intake;
        this.recordDate = recordDate;
    }

    // Getters and Setters
    public int getRecordId() {
        return recordId;
    }

    public void setRecordId(int recordId) {
        this.recordId = recordId;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public int getFoodCode() {
        return foodCode;
    }

    public void setFoodCode(int foodCode) {
        this.foodCode = foodCode;
    }

    public int getIntake() {
        return intake;
    }

    public void setIntake(int intake) {
        this.intake = intake;
    }

    public Date getRecordDate() {
        return recordDate;
    }

    public void setRecordDate(Date recordDate) {
        this.recordDate = recordDate;
    }

    @Override
    public String toString() {
        return "DietRecord{" +
                "recordId=" + recordId +
                ", userId='" + userId + '\'' +
                ", foodCode=" + foodCode +
                ", intake=" + intake +
                ", recordDate=" + recordDate +
                '}';
    }
}
