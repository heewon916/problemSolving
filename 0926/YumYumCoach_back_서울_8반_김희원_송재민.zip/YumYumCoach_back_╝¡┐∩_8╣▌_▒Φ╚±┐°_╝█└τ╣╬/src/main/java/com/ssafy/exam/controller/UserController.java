package com.ssafy.exam.controller;

import com.ssafy.exam.model.dto.User;
import com.ssafy.exam.model.service.UserService;
import com.ssafy.exam.model.service.UserServiceImpl;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

public class UserController {

    private final UserService userService = UserServiceImpl.getInstance();

    public String loginForm(HttpServletRequest request, HttpServletResponse response) {
        return "/login-form.jsp";
    }

    public String login(HttpServletRequest request, HttpServletResponse response) {
        String userId = request.getParameter("userId");
        String password = request.getParameter("password");

        User user = userService.login(userId, password);

        if (user != null) {
            HttpSession session = request.getSession();
            session.setAttribute("loginUser", user);
            return "redirect:/"; // 로그인 성공 시 메인 페이지로 리다이렉트
        } else {
            request.setAttribute("errorMsg", "아이디 또는 비밀번호가 일치하지 않습니다.");
            return "/login-form.jsp";
        }
    }

    public String logout(HttpServletRequest request, HttpServletResponse response) {
        HttpSession session = request.getSession(false);
        if (session != null) {
            session.invalidate();
        }
        return "redirect:/";
    }

    public String signupForm(HttpServletRequest request, HttpServletResponse response) {
        return "/user/signup.jsp";
    }

    public String signup(HttpServletRequest request, HttpServletResponse response) {
        String id = request.getParameter("id");
        String password = request.getParameter("password");
        String name = request.getParameter("name");
        double height = Double.parseDouble(request.getParameter("height"));
        double weight = Double.parseDouble(request.getParameter("weight"));
        String disease = request.getParameter("disease");

        User user = new User(id, password, name, height, weight, disease);

        try {
            userService.join(user);
            return "redirect:/user/login.do"; // 회원가입 성공 시 로그인 페이지로
        } catch (IllegalArgumentException e) {
            request.setAttribute("errorMsg", e.getMessage());
            return "/user/signup.jsp";
        }
    }

    public String mypage(HttpServletRequest request, HttpServletResponse response) {
        // 세션에서 로그인 정보 확인 (필터에서 처리하는 것이 더 좋음)
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("loginUser") == null) {
            return "redirect:/user/login.do";
        }
        return "/user/mypage.jsp";
    }

    public String updateUser(HttpServletRequest request, HttpServletResponse response) {
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("loginUser") == null) {
            return "redirect:/user/login.do";
        }

        String id = request.getParameter("id");
        String newPassword = request.getParameter("password");
        String name = request.getParameter("name");
        double height = Double.parseDouble(request.getParameter("height"));
        double weight = Double.parseDouble(request.getParameter("weight"));
        String disease = request.getParameter("disease");

        User loginUser = (User) session.getAttribute("loginUser");
        // 비밀번호가 입력된 경우에만 변경
        String password = (newPassword == null || newPassword.isEmpty()) ? loginUser.getPassword() : newPassword;

        User userToUpdate = new User(id, password, name, height, weight, disease);
        userService.modifyUser(userToUpdate);

        // 세션 정보도 업데이트
        session.setAttribute("loginUser", userToUpdate);

        return "redirect:/user/mypage.do";
    }

    public String deleteUser(HttpServletRequest request, HttpServletResponse response) {
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("loginUser") == null) {
            return "redirect:/user/login.do";
        }

        User loginUser = (User) session.getAttribute("loginUser");
        userService.removeUser(loginUser.getId());
        session.invalidate(); // 세션 무효화 (로그아웃)
        return "redirect:/";
    }
}