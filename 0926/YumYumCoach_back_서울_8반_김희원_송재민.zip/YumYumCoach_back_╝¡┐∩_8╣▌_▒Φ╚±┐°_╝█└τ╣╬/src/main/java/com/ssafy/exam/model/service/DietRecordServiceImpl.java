package com.ssafy.exam.model.service;

import com.ssafy.exam.model.dao.CoachDao;
import com.ssafy.exam.model.dao.FileCoachDao;
import com.ssafy.exam.model.dto.DietRecord;
import com.ssafy.exam.model.dto.Food;
import com.ssafy.exam.model.dto.User;

import java.util.List;

public class DietRecordServiceImpl implements DietRecordService {

    private final CoachDao coachDao = FileCoachDao.getInstance();
    private static final DietRecordServiceImpl instance = new DietRecordServiceImpl();

    private DietRecordServiceImpl() {}

    public static DietRecordServiceImpl getInstance() {
        return instance;
    }

    @Override
    public List<DietRecord> getDietRecords(String userId) {
        return coachDao.selectAllDietRecords(userId);
    }

    @Override
    public DietRecord getDietRecordById(int recordId) {
        return coachDao.selectDietRecordById(recordId);
    }

    @Override
    public void addDietRecord(DietRecord dietRecord) {
        // 비즈니스 로직 (e.g., 유효한 사용자인지, 음식 코드가 유효한지 확인)
        if (coachDao.selectUserById(dietRecord.getUserId()) == null) {
            throw new IllegalArgumentException("존재하지 않는 사용자입니다.");
        }
        if (coachDao.selectFoodByCode(dietRecord.getFoodCode()) == null) {
            throw new IllegalArgumentException("존재하지 않는 음식입니다.");
        }
        coachDao.insertDietRecord(dietRecord);
    }

    @Override
    public void modifyDietRecord(DietRecord dietRecord) {
        coachDao.updateDietRecord(dietRecord);
    }

    @Override
    public void removeDietRecord(int recordId) {
        coachDao.deleteDietRecord(recordId);
    }

    @Override
    public List<Food> getAllFoods() {
        return coachDao.selectAllFoods();
    }

    @Override
    public double calculateDietScore(String userId) {
        User user = coachDao.selectUserById(userId);
        if (user == null) return 0;

        List<DietRecord> records = getDietRecords(userId);
        if (records.isEmpty()) return 50; // 기록이 없으면 중간 점수

        double totalCalories = 0;
        double totalCarbs = 0;
        double totalProtein = 0;
        double totalFat = 0;

        for (DietRecord record : records) {
            Food food = coachDao.selectFoodByCode(record.getFoodCode());
            if (food != null) {
                double intakeRatio = record.getIntake() / 100.0; // 100g 기준
                totalCalories += food.getCalories() * intakeRatio;
                totalCarbs += food.getCarbohydrate() * intakeRatio;
                totalProtein += food.getProtein() * intakeRatio;
                totalFat += food.getFat() * intakeRatio;
            }
        }

        // 기초대사량 (BMR) - 해리스-베네딕트 공식
        double bmr = 66.47 + (13.75 * user.getWeight()) + (5 * user.getHeight()) - (6.76 * 30); // 나이는 30으로 가정
        // 하루 권장 칼로리 (활동량 보통으로 가정)
        double recommendedCalories = bmr * 1.55;

        // 점수 계산 로직 (단순화)
        // 1. 칼로리 점수 (권장량의 90% ~ 110% 사이면 만점)
        double calorieScore = 0;
        double calorieRatio = totalCalories / recommendedCalories;
        if (calorieRatio >= 0.9 && calorieRatio <= 1.1) {
            calorieScore = 40;
        } else {
            calorieScore = 40 * (1 - Math.abs(1 - calorieRatio));
        }

        // 2. 영양소 균형 점수 (탄:단:지 = 5:3:2 비율 기준)
        double totalNutrients = totalCarbs + totalProtein + totalFat;
        if (totalNutrients == 0) return Math.max(0, calorieScore); // 영양소가 없으면 칼로리 점수만 반환
        
        double carbRatio = totalCarbs / totalNutrients;
        double proteinRatio = totalProtein / totalNutrients;
        double fatRatio = totalFat / totalNutrients;

        double carbBalanceScore = 30 * (1 - Math.abs(carbRatio - 0.5));
        double proteinBalanceScore = 30 * (1 - Math.abs(proteinRatio - 0.3));
        // double fatBalanceScore = 20 * (1 - Math.abs(fatRatio - 0.2));

        double balanceScore = carbBalanceScore + proteinBalanceScore;

        double finalScore = calorieScore + balanceScore;

        return Math.max(0, Math.min(100, finalScore)); // 0~100점 사이로 보정
    }
}
