package com.ssafy.exam.controller;

import com.ssafy.exam.model.dto.DietRecord;
import com.ssafy.exam.model.dto.Food;
import com.ssafy.exam.model.dto.User;
import com.ssafy.exam.model.dto.DietRecordView;
import com.ssafy.exam.model.service.DietRecordService;
import com.ssafy.exam.model.service.DietRecordServiceImpl;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.util.*;
import java.util.stream.Collectors;

public class DietController {

    private final DietRecordService dietRecordService = DietRecordServiceImpl.getInstance();

    public String list(HttpServletRequest request, HttpServletResponse response) throws ServletException {
        try {
            HttpSession session = request.getSession(false);
            if (session == null || session.getAttribute("loginUser") == null) {
                return "redirect:/user/login.do";
            }
            System.out.println("[DEBUG] DietController.list: Session valid.");

            User loginUser = (User) session.getAttribute("loginUser");
            List<DietRecord> records = dietRecordService.getDietRecords(loginUser.getId());
            System.out.println("[DEBUG] DietController.list: Found " + records.size() + " diet records.");

            Map<Integer, String> foodNameMap = dietRecordService.getAllFoods().stream()
                    .collect(Collectors.toMap(Food::getCode, Food::getName, (name1, name2) -> name1)); // 중복 키 에러 방지
            System.out.println("[DEBUG] DietController.list: Food map created with " + foodNameMap.size() + " entries.");

            List<DietRecordView> recordViews = new ArrayList<>();
            for (DietRecord record : records) {
                String foodName = foodNameMap.getOrDefault(record.getFoodCode(), "알 수 없는 음식");
                recordViews.add(new DietRecordView(record, foodName));
            }
            System.out.println("[DEBUG] DietController.list: Created " + recordViews.size() + " view objects.");

            request.setAttribute("records", recordViews);

            return "/diet/list.jsp";
        } catch (Exception e) {
            // 에러의 근본 원인을 추적하기 쉽게 콘솔에 스택 트레이스를 출력합니다.
            e.printStackTrace();
            // MainController가 에러를 처리할 수 있도록 예외를 다시 던집니다.
            throw new ServletException(e);
        }
    }

    public String addForm(HttpServletRequest request, HttpServletResponse response) {
        // 세션 체크는 필터에서 공통으로 처리하는 것이 이상적
        List<Food> foods = dietRecordService.getAllFoods();
        request.setAttribute("foods", foods);
        return "/diet/add.jsp";
    }

    public String add(HttpServletRequest request, HttpServletResponse response) {
        HttpSession session = request.getSession(false);
        User loginUser = (User) session.getAttribute("loginUser");

        int foodCode = Integer.parseInt(request.getParameter("foodCode"));
        int intake = Integer.parseInt(request.getParameter("intake"));

        DietRecord dietRecord = new DietRecord(0, loginUser.getId(), foodCode, intake, new Date());
        dietRecordService.addDietRecord(dietRecord);

        return "redirect:/diet/list.do";
    }
    
    public String analysis(HttpServletRequest request, HttpServletResponse response) {
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("loginUser") == null) {
            return "redirect:/user/login.do";
        }

        User loginUser = (User) session.getAttribute("loginUser");
        double score = dietRecordService.calculateDietScore(loginUser.getId());
        request.setAttribute("score", score);
        
        // 추가적으로 상세 분석 정보를 넘겨줄 수 있음
        // 예: 총 칼로리, 영양소별 섭취량 등

        return "/diet/analysis.jsp";
    }

    public String delete(HttpServletRequest request, HttpServletResponse response) {
        int recordId = Integer.parseInt(request.getParameter("recordId"));
        // TODO: 본인의 기록이 맞는지 확인하는 로직 추가하면 더 좋음
        dietRecordService.removeDietRecord(recordId);
        return "redirect:/diet/list.do";
    }

    public String detail(HttpServletRequest request, HttpServletResponse response) {
        int recordId = Integer.parseInt(request.getParameter("recordId"));
        DietRecord record = dietRecordService.getDietRecordById(recordId);

        // 본인 기록이 맞는지 확인하는 로직 추가하면 더 좋음

        Food food = dietRecordService.getAllFoods().stream()
                        .filter(f -> f.getCode() == record.getFoodCode())
                        .findFirst().orElse(null);
        String foodName = (food != null) ? food.getName() : "알 수 없는 음식";

        DietRecordView recordView = new DietRecordView(record, foodName);
        request.setAttribute("record", recordView);

        return "/diet/detail.jsp";
    }

    public String editForm(HttpServletRequest request, HttpServletResponse response) {
        int recordId = Integer.parseInt(request.getParameter("recordId"));
        DietRecord record = dietRecordService.getDietRecordById(recordId);
        request.setAttribute("record", record);

        List<Food> foods = dietRecordService.getAllFoods();
        request.setAttribute("foods", foods);

        return "/diet/edit.jsp";
    }

    public String edit(HttpServletRequest request, HttpServletResponse response) {
        int recordId = Integer.parseInt(request.getParameter("recordId"));
        int foodCode = Integer.parseInt(request.getParameter("foodCode"));
        int intake = Integer.parseInt(request.getParameter("intake"));

        DietRecord originalRecord = dietRecordService.getDietRecordById(recordId);
        // 본인 기록이 맞는지 확인하는 로직 추가하면 더 좋음

        DietRecord dietRecord = new DietRecord(recordId, originalRecord.getUserId(), foodCode, intake, new Date());
        dietRecordService.modifyDietRecord(dietRecord);

        return "redirect:/diet/detail.do?recordId=" + recordId;
    }
}