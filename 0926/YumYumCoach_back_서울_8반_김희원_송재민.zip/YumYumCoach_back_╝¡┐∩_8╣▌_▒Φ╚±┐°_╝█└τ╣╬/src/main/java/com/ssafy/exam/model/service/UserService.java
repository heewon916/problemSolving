package com.ssafy.exam.model.service;

import com.ssafy.exam.model.dto.User;

import java.util.List;

public interface UserService {
    List<User> getAllUsers();
    User getUserById(String userId);
    void join(User user);
    void modifyUser(User user);
    void removeUser(String userId);
    User login(String userId, String password);
}
