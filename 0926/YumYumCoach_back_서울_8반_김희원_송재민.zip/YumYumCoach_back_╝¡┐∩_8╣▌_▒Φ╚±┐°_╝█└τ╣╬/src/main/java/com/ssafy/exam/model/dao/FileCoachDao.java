package com.ssafy.exam.model.dao;

import com.ssafy.exam.model.dto.DietRecord;
import com.ssafy.exam.model.dto.Food;
import com.ssafy.exam.model.dto.User;

import java.io.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

public class FileCoachDao implements CoachDao {

    private final File userDataFile;
    private final File foodDataFile;
    private final File dietRecordDataFile;

    private List<User> users;
    private List<Food> foods;
    private List<DietRecord> dietRecords;
    private AtomicInteger dietRecordIdCounter = new AtomicInteger(1);

    private static final FileCoachDao instance = new FileCoachDao();

    private FileCoachDao() {
        String basePath = FileCoachDao.class.getResource("/").getPath();
        userDataFile = new File(basePath + "users.dat");
        foodDataFile = new File(basePath + "foods.dat");
        dietRecordDataFile = new File(basePath + "diet_records.dat");

        try {
            if (!userDataFile.exists()) userDataFile.createNewFile();
            if (!foodDataFile.exists()) foodDataFile.createNewFile();
            if (!dietRecordDataFile.exists()) dietRecordDataFile.createNewFile();
        } catch (IOException e) {
            throw new RuntimeException("Data file creation failed", e);
        }
    }

    public static FileCoachDao getInstance() {
        return instance;
    }

    @SuppressWarnings("unchecked")
    public void load() {
        // 각 파일을 독립적으로 로드하여 하나의 파일 오류가 다른 파일에 영향을 주지 않도록 수정
        try (ObjectInputStream userOis = new ObjectInputStream(new FileInputStream(userDataFile))) {
            users = (List<User>) userOis.readObject();
            System.out.println("User data loaded: " + (users != null ? users.size() : 0));
        } catch (EOFException | ClassNotFoundException e) {
            System.out.println("No saved user data found. Initializing new list.");
        } catch (IOException e) {
            System.err.println("Error loading user data: " + e.getMessage());
        }

        try (ObjectInputStream foodOis = new ObjectInputStream(new FileInputStream(foodDataFile))) {
            foods = (List<Food>) foodOis.readObject();
            System.out.println("Food data loaded: " + (foods != null ? foods.size() : 0));
        } catch (EOFException | ClassNotFoundException e) {
            System.out.println("No saved food data found. Initializing new list.");
        } catch (IOException e) {
            System.err.println("Error loading food data: " + e.getMessage());
        }

        try (ObjectInputStream dietOis = new ObjectInputStream(new FileInputStream(dietRecordDataFile))) {
            dietRecords = (List<DietRecord>) dietOis.readObject();
            if (dietRecords != null && !dietRecords.isEmpty()) {
                int maxId = dietRecords.stream().mapToInt(DietRecord::getRecordId).max().orElse(0);
                dietRecordIdCounter.set(maxId + 1);
            }
            System.out.println("DietRecord data loaded: " + (dietRecords != null ? dietRecords.size() : 0));
        } catch (EOFException | ClassNotFoundException e) {
            System.out.println("No saved diet record data found. Initializing new list.");
        } catch (IOException e) {
            System.err.println("Error loading diet record data: " + e.getMessage());
        }

        // 리스트가 null이면 초기화
        if (users == null) users = Collections.synchronizedList(new ArrayList<>());
        if (foods == null) foods = Collections.synchronizedList(new ArrayList<>());
        if (dietRecords == null) dietRecords = Collections.synchronizedList(new ArrayList<>());

        // 초기 데이터가 비어있으면 샘플 데이터 생성
        if (users.isEmpty()) initUsers();
        initFoods();
    }

    public void save() {
        try (ObjectOutputStream userOos = new ObjectOutputStream(new FileOutputStream(userDataFile));
             ObjectOutputStream foodOos = new ObjectOutputStream(new FileOutputStream(foodDataFile));
             ObjectOutputStream dietOos = new ObjectOutputStream(new FileOutputStream(dietRecordDataFile))) {

            userOos.writeObject(users);
            foodOos.writeObject(foods);
            dietOos.writeObject(dietRecords);

            System.out.println("All data saved successfully.");

        } catch (IOException e) {
            throw new RuntimeException("Failed to save data", e);
        }
    }
    
    private void initUsers() {
        users.add(new User("ssafy", "1234", "김싸피", 175, 70, "없음"));
        users.add(new User("admin", "1234", "관리자", 180, 75, "없음"));
        System.out.println("Initial user data created.");
    }

    private void initFoods() {
        foods.clear();
        foods.add(new Food(1, "국밥_돼지머리", 137.0, 15.94, 6.7, 5.16));
        foods.add(new Food(2, "국밥_순대국밥", 75.0, 10.38, 3.17, 2.28));
        foods.add(new Food(3, "국밥_콩나물", 52.0, 10.93, 1.45, 0.24));
        foods.add(new Food(4, "기장밥", 166.0, 36.77, 3.44, 0.57));
        foods.add(new Food(5, "김밥", 140.0, 19.98, 4.84, 4.55));
        foods.add(new Food(6, "김밥_김치", 130.0, 19.17, 4.3, 4.03));
        foods.add(new Food(7, "김밥_날치알", 177.0, 28.66, 6.1, 4.26));
        foods.add(new Food(8, "김밥_돈가스", 202.0, 31.64, 5.77, 5.81));
        foods.add(new Food(9, "김밥_소고기", 179.0, 25.78, 6.46, 5.56));
        foods.add(new Food(10, "김밥_참치", 174.0, 20.26, 7.0, 7.22));
        foods.add(new Food(11, "김밥_채소", 158.0, 26.65, 4.6, 3.65));
        foods.add(new Food(12, "김밥_치즈", 177.0, 22.1, 6.24, 7.03));
        foods.add(new Food(13, "김밥_풋고추", 169.0, 27.52, 4.88, 4.41));
        foods.add(new Food(14, "덮밥_낙지", 150.0, 24.12, 5.88, 3.34));
        foods.add(new Food(15, "덮밥_닭고기", 125.0, 14.82, 11.4, 2.18));
        foods.add(new Food(16, "덮밥_돼지고기(제육)", 202.0, 16.86, 9.43, 10.77));
        foods.add(new Food(17, "덮밥_불고기", 182.0, 26.96, 6.6, 5.31));
        foods.add(new Food(18, "덮밥_오징어", 135.0, 21.94, 7.18, 2.01));
        foods.add(new Food(19, "보리밥", 161.0, 36.77, 2.9, 0.24));
        foods.add(new Food(20, "볶음밥", 183.0, 33.97, 5.56, 2.76));
        foods.add(new Food(21, "볶음밥_계란", 225.0, 24.23, 6.62, 11.28));
        foods.add(new Food(22, "볶음밥_김치", 167.0, 15.74, 5.32, 9.18));
        foods.add(new Food(23, "볶음밥_새우", 172.0, 22.85, 6.31, 6.14));
        foods.add(new Food(24, "볶음밥_소고기", 176.0, 21.76, 7.59, 6.48));
        foods.add(new Food(25, "볶음밥_참치", 180.0, 32.9, 4.62, 3.27));
        foods.add(new Food(26, "볶음밥_채소", 182.0, 28.74, 4.72, 5.39));
        foods.add(new Food(27, "볶음밥_표고버섯", 184.0, 31.79, 3.36, 4.81));
        foods.add(new Food(28, "비빔밥", 142.0, 18.84, 6.86, 4.32));
        foods.add(new Food(29, "비빔밥_돌솥", 147.0, 24.68, 5.39, 2.95));
        foods.add(new Food(30, "비빔밥_육회", 147.0, 22.92, 6.39, 3.36));
        foods.add(new Food(31, "삼각김밥_참치마요네즈", 199.0, 25.45, 5.93, 8.21));
        foods.add(new Food(32, "수수밥", 161.0, 35.02, 3.16, 0.92));
        foods.add(new Food(33, "알밥", 128.0, 15.75, 4.73, 5.11));
        foods.add(new Food(34, "영양돌솥밥", 184.0, 36.06, 3.43, 2.87));
        foods.add(new Food(35, "오므라이스", 173.0, 20.54, 6.5, 7.23));
        foods.add(new Food(36, "자장밥", 122.0, 15.57, 4.27, 4.72));
        foods.add(new Food(37, "잡곡밥", 146.0, 29.33, 5.3, 0.87));
        foods.add(new Food(38, "잡채밥", 150.0, 25.79, 4.02, 3.42));
        foods.add(new Food(39, "주먹밥_소고기", 178.0, 34.73, 4.76, 2.18));
        foods.add(new Food(40, "짬뽕밥", 72.0, 11.65, 3.2, 1.4));
        foods.add(new Food(41, "차조밥", 157.0, 34.86, 2.84, 0.65));
        foods.add(new Food(42, "찰밥", 153.0, 33.56, 4.39, 0.18));
        foods.add(new Food(43, "초밥_모듬", 160.0, 26.72, 9.66, 1.59));
        foods.add(new Food(44, "초밥_유부초밥", 194.0, 29.82, 5.78, 5.77));
        foods.add(new Food(45, "카레라이스", 108.0, 20.74, 3.11, 1.4));
        foods.add(new Food(46, "콩나물밥", 123.0, 22.39, 4.68, 1.58));
        foods.add(new Food(47, "콩밥_검정콩", 165.0, 34.3, 4.53, 1.12));
        foods.add(new Food(48, "콩밥_완두콩", 138.0, 31.25, 2.95, 0.16));
        foods.add(new Food(49, "하이라이스", 112.0, 21.34, 4.02, 1.13));
        foods.add(new Food(50, "현미밥", 172.0, 38.9, 3.1, 0.47));
        foods.add(new Food(51, "회덮밥_모듬", 145.0, 17.76, 9.1, 4.15));
        foods.add(new Food(52, "가래떡", 195.0, 43.73, 3.92, 0.51));
        foods.add(new Food(53, "경단_깨", 240.0, 38.58, 6.28, 6.72));
        foods.add(new Food(54, "꿀떡", 228.0, 49.48, 3.74, 1.73));
        foods.add(new Food(55, "모듬찰떡", 218.0, 42.27, 6.78, 2.44));
        foods.add(new Food(56, "백설기", 230.0, 50.4, 3.71, 1.45));
        foods.add(new Food(57, "송편_깨", 219.0, 42.83, 4.65, 3.23));
        foods.add(new Food(58, "시루떡", 224.0, 48.13, 3.77, 1.85));
        foods.add(new Food(59, "약식", 220.0, 45.24, 4.21, 2.45));
        foods.add(new Food(60, "인절미", 242.0, 50.07, 5.64, 2.16));
        foods.add(new Food(61, "절편_쑥", 192.0, 34.87, 7.72, 2.42));
        foods.add(new Food(62, "증편", 200.0, 44.15, 3.17, 1.2));
        foods.add(new Food(63, "찹쌀떡_팥", 295.0, 62.93, 5.06, 2.53));
        foods.add(new Food(64, "도넛_링도넛", 515.0, 46.16, 7.85, 33.17));
        foods.add(new Food(65, "도넛_찹쌀", 288.0, 55.56, 6.0, 4.64));
        foods.add(new Food(66, "마늘빵", 438.0, 57.94, 12.06, 17.58));
        foods.add(new Food(67, "머핀", 384.0, 59.15, 5.73, 13.84));
        foods.add(new Food(68, "모닝빵", 314.0, 52.17, 9.5, 7.43));
        foods.add(new Food(69, "모카빵", 339.0, 57.96, 8.55, 8.05));
        foods.add(new Food(70, "베이글", 306.0, 53.48, 10.0, 5.83));
        foods.add(new Food(71, "샌드위치_닭가슴살", 240.0, 20.96, 12.18, 11.92));
        foods.add(new Food(72, "샌드위치_모듬", 193.0, 8.44, 9.5, 13.44));
        foods.add(new Food(73, "샌드위치_참치", 202.0, 13.78, 10.54, 11.65));
        foods.add(new Food(74, "샌드위치_채소", 244.0, 23.82, 4.08, 14.75));
        foods.add(new Food(75, "샌드위치_햄_달걀", 220.0, 15.64, 12.44, 11.92));
        foods.add(new Food(76, "소보로빵", 392.0, 55.63, 8.27, 15.13));
        foods.add(new Food(77, "식빵", 264.0, 50.91, 9.34, 2.6));
        foods.add(new Food(78, "초코소라빵", 319.0, 51.76, 3.29, 10.93));
        foods.add(new Food(79, "츄러스", 361.0, 58.17, 6.6, 11.29));
        foods.add(new Food(80, "카스텔라", 335.0, 47.99, 10.03, 11.47));
        foods.add(new Food(81, "케이크_롤케이크", 312.0, 44.01, 7.36, 11.83));
        foods.add(new Food(82, "케이크_생크림케이크", 237.0, 27.62, 3.45, 12.54));
        foods.add(new Food(83, "크로와상", 446.0, 43.31, 7.52, 26.98));
        foods.add(new Food(84, "파이/만주_사과파이", 185.0, 34.83, 2.54, 3.91));
        foods.add(new Food(85, "페이스트리", 466.0, 41.5, 8.31, 29.66));
        foods.add(new Food(86, "피자_콤비네이션피자", 274.0, 25.54, 10.68, 14.36));
        foods.add(new Food(87, "피자빵", 298.0, 31.76, 8.85, 15.05));
        foods.add(new Food(88, "햄버거", 264.0, 21.67, 12.85, 13.98));
        foods.add(new Food(89, "햄버거_불고기버거", 250.0, 22.68, 13.88, 11.52));
        foods.add(new Food(90, "호떡_견과류", 314.0, 57.12, 5.41, 7.07));
        foods.add(new Food(91, "간자장", 125.0, 15.13, 5.12, 4.89));
        foods.add(new Food(92, "국수_막국수", 133.0, 23.9, 5.8, 1.61));
        foods.add(new Food(93, "국수_비빔국수", 102.0, 20.47, 3.01, 0.95));
        foods.add(new Food(94, "국수_잔치국수", 44.0, 8.05, 1.93, 0.49));
        foods.add(new Food(95, "국수_쟁반막국수", 119.0, 12.81, 6.68, 4.56));
        foods.add(new Food(96, "냉면_물냉면", 55.0, 10.31, 1.96, 0.64));
        foods.add(new Food(97, "냉면_비빔냉면", 100.0, 13.35, 5.67, 2.64));
        foods.add(new Food(98, "냉면_회냉면_홍어", 148.0, 22.21, 5.81, 4.02));
        foods.add(new Food(99, "떡국", 84.0, 16.37, 3.43, 0.53));
        foods.add(new Food(100, "떡만두국", 111.0, 15.47, 3.53, 3.91));
        foods.add(new Food(101, "라면", 82.0, 13.65, 1.72, 2.28));
        foods.add(new Food(102, "라면_달걀", 108.0, 17.33, 2.61, 3.18));
        foods.add(new Food(103, "라면_떡", 96.0, 15.27, 2.04, 2.92));
        foods.add(new Food(104, "만두_고기만두", 159.0, 17.4, 12.38, 4.45));
        foods.add(new Food(105, "만두_군만두", 234.0, 25.57, 7.03, 11.5));
        foods.add(new Food(106, "만두_김치만두", 152.0, 17.02, 10.24, 4.76));
        foods.add(new Food(107, "만두_물만두", 195.0, 15.61, 8.06, 11.13));
        foods.add(new Food(108, "만두국_사골", 87.0, 8.94, 3.74, 4.0));
        foods.add(new Food(109, "메밀국수_온면", 63.0, 12.06, 3.14, 0.29));
        foods.add(new Food(110, "수제비", 58.0, 11.08, 2.31, 0.52));
        foods.add(new Food(111, "스파게티_미트볼", 180.0, 17.62, 7.34, 8.88));
        foods.add(new Food(112, "우동_일식", 158.0, 30.48, 1.78, 3.22));
        foods.add(new Food(113, "우동볶음", 128.0, 24.79, 2.8, 2.01));
        foods.add(new Food(114, "월남쌈", 118.0, 12.25, 5.94, 4.97));
        foods.add(new Food(115, "자장면", 88.0, 14.37, 2.69, 2.22));
        foods.add(new Food(116, "짬뽕", 58.0, 8.26, 2.79, 1.54));
        foods.add(new Food(117, "쫄면", 129.0, 23.26, 3.21, 2.52));
        foods.add(new Food(118, "칼국수", 77.0, 14.9, 3.3, 0.49));
        foods.add(new Food(119, "칼국수_바지락", 82.0, 15.97, 3.43, 0.53));
        foods.add(new Food(120, "콩국수", 81.0, 8.92, 3.9, 3.35));
        foods.add(new Food(121, "닭죽", 44.0, 7.14, 2.68, 0.57));
        foods.add(new Food(122, "스프_양송이버섯", 105.0, 8.06, 2.41, 7.04));
        foods.add(new Food(123, "오리죽", 155.0, 19.95, 7.5, 4.99));
        foods.add(new Food(124, "전복죽", 79.0, 9.62, 1.82, 3.73));
        foods.add(new Food(125, "채소죽", 43.0, 7.62, 1.69, 0.69));
        foods.add(new Food(126, "팥죽", 81.0, 16.66, 3.17, 0.19));
        foods.add(new Food(127, "호박죽", 49.0, 6.58, 1.93, 1.71));
        foods.add(new Food(128, "흑임자 죽", 61.0, 3.64, 1.1, 4.73));
        foods.add(new Food(129, "갈비탕", 54.0, 0.4, 8.51, 2.06));
        foods.add(new Food(130, "감자국", 21.0, 3.67, 0.9, 0.26));
        foods.add(new Food(131, "곰탕", 24.0, 0.11, 3.43, 1.12));
        foods.add(new Food(132, "곰탕_우거지", 25.0, 2.6, 2.37, 0.6));
        foods.add(new Food(133, "굴국_무", 25.0, 2.93, 2.41, 0.36));
        foods.add(new Food(134, "김치국", 23.0, 2.63, 1.34, 0.76));
        foods.add(new Food(135, "김치국_콩나물", 12.0, 1.15, 0.82, 0.47));
        foods.add(new Food(136, "내장탕", 71.0, 1.68, 5.82, 4.52));
        foods.add(new Food(137, "냉국_미역", 37.0, 7.51, 0.19, 0.67));
        foods.add(new Food(138, "냉국_미역_오이", 6.0, 0.85, 0.37, 0.15));
        foods.add(new Food(139, "달걀국", 13.0, 0.69, 0.93, 0.74));
        foods.add(new Food(140, "달걀탕_순두부", 29.0, 0.94, 1.78, 2.04));
        foods.add(new Food(141, "닭곰탕", 51.0, 2.0, 7.51, 1.42));
        foods.add(new Food(142, "도가니탕", 40.0, 0.82, 8.35, 0.33));
        foods.add(new Food(143, "된장국_감자", 25.0, 3.7, 1.09, 0.6));
        foods.add(new Food(144, "된장국_냉이", 22.0, 2.2, 1.71, 0.66));
        foods.add(new Food(145, "된장국_미역", 24.0, 2.28, 1.56, 0.97));
        foods.add(new Food(146, "된장국_배추", 20.0, 2.58, 1.46, 0.4));
        foods.add(new Food(147, "된장국_시금치", 9.0, 0.98, 1.02, 0.17));
        foods.add(new Food(148, "된장국_시래기", 15.0, 2.03, 1.31, 0.22));
        foods.add(new Food(149, "된장국_쑥", 15.0, 1.52, 1.22, 0.47));
        foods.add(new Food(150, "된장국_아욱", 20.0, 1.59, 2.28, 0.56));
        System.out.println("Initial 150 real food data created.");
    }

    @Override
    public List<User> selectAllUsers() {
        return new ArrayList<>(users);
    }

    @Override
    public User selectUserById(String userId) {
        return users.stream().filter(u -> u.getId().equals(userId)).findFirst().orElse(null);
    }

    @Override
    public void insertUser(User user) {
        users.add(user);
    }

    @Override
    public void updateUser(User user) {
        User oldUser = selectUserById(user.getId());
        if (oldUser != null) {
            oldUser.setName(user.getName());
            oldUser.setPassword(user.getPassword());
            oldUser.setHeight(user.getHeight());
            oldUser.setWeight(user.getWeight());
            oldUser.setDisease(user.getDisease());
        }
    }

    @Override
    public void deleteUser(String userId) {
        users.removeIf(u -> u.getId().equals(userId));
    }

    @Override
    public User login(String userId, String password) {
        return users.stream()
                .filter(u -> u.getId().equals(userId) && u.getPassword().equals(password))
                .findFirst()
                .orElse(null);
    }

    @Override
    public List<Food> selectAllFoods() {
        return new ArrayList<>(foods);
    }

    @Override
    public Food selectFoodByCode(int foodCode) {
        return foods.stream().filter(f -> f.getCode() == foodCode).findFirst().orElse(null);
    }

    @Override
    public List<DietRecord> selectAllDietRecords(String userId) {
        return dietRecords.stream().filter(dr -> dr.getUserId().equals(userId)).collect(Collectors.toList());
    }

    @Override
    public DietRecord selectDietRecordById(int recordId) {
        return dietRecords.stream().filter(dr -> dr.getRecordId() == recordId).findFirst().orElse(null);
    }

    @Override
    public void insertDietRecord(DietRecord dietRecord) {
        dietRecord.setRecordId(dietRecordIdCounter.getAndIncrement());
        dietRecords.add(dietRecord);
    }

    @Override
    public void updateDietRecord(DietRecord dietRecord) {
        DietRecord oldRecord = selectDietRecordById(dietRecord.getRecordId());
        if (oldRecord != null) {
            oldRecord.setFoodCode(dietRecord.getFoodCode());
            oldRecord.setIntake(dietRecord.getIntake());
            oldRecord.setRecordDate(dietRecord.getRecordDate());
        }
    }

    @Override
    public void deleteDietRecord(int recordId) {
        dietRecords.removeIf(dr -> dr.getRecordId() == recordId);
    }
}
