package com.ssafy.exam.controller;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("*.do")
public class MainController extends HttpServlet {
    private static final long serialVersionUID = 1L;

    private UserController userController;
    private DietController dietController;

    @Override
    public void init() throws ServletException {
        userController = new UserController();
        dietController = new DietController();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        process(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        process(request, response);
    }

    private void process(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String requestURI = request.getRequestURI();
        String contextPath = request.getContextPath();
        String action = requestURI.substring(contextPath.length());

        System.out.println("Request URI: " + requestURI);
        System.out.println("Action: " + action);

        String path = "/index.jsp"; // 기본 경로

        try {
            if (action.startsWith("/user")) {
                path = handleUserAction(action, request, response);
            } else if (action.startsWith("/diet")) {
                path = handleDietAction(action, request, response);
            }

            if (path.startsWith("redirect:")) {
                response.sendRedirect(contextPath + path.substring("redirect:".length()));
            } else {
                RequestDispatcher dispatcher = request.getRequestDispatcher(path);
                dispatcher.forward(request, response);
            }
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("errorMsg", "처리 중 오류가 발생했습니다: " + e.getMessage());
            request.getRequestDispatcher("/error/500.jsp").forward(request, response);
        }
    }

    private String handleUserAction(String action, HttpServletRequest request, HttpServletResponse response) throws Exception {
        switch (action) {
            case "/user/login.do":
                return userController.login(request, response);
            case "/user/login-form.do":
                return userController.loginForm(request, response);
            case "/user/logout.do":
                return userController.logout(request, response);
            case "/user/signup.do":
                return userController.signup(request, response);
            case "/user/signup-form.do":
                return userController.signupForm(request, response);
            case "/user/mypage.do":
                return userController.mypage(request, response);
            case "/user/update.do":
                return userController.updateUser(request, response);
            case "/user/delete.do":
                return userController.deleteUser(request, response);
            default:
                return "/error/404.jsp";
        }
    }

    private String handleDietAction(String action, HttpServletRequest request, HttpServletResponse response) throws Exception {
        switch (action) {
            case "/diet/list.do":
                return dietController.list(request, response);
            case "/diet/add.do":
                return dietController.add(request, response);
            case "/diet/add-form.do":
                return dietController.addForm(request, response);
            case "/diet/analysis.do":
                return dietController.analysis(request, response);
            case "/diet/delete.do":
                return dietController.delete(request, response);
            case "/diet/detail.do":
                return dietController.detail(request, response);
            case "/diet/edit-form.do":
                return dietController.editForm(request, response);
            case "/diet/edit.do":
                return dietController.edit(request, response);
            default:
                return "/error/404.jsp";
        }
    }
}
