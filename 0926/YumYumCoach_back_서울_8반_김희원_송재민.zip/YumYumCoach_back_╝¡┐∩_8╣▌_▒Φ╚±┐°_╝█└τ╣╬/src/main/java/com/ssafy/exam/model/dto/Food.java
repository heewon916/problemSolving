package com.ssafy.exam.model.dto;

import java.io.Serializable;

public class Food implements Serializable {
    private static final long serialVersionUID = 1L;

    private int code; // 식품 코드
    private String name; // 식품 이름
    private double calories; // 칼로리
    private double carbohydrate; // 탄수화물
    private double protein; // 단백질
    private double fat; // 지방

    public Food() {}

    public Food(int code, String name, double calories, double carbohydrate, double protein, double fat) {
        this.code = code;
        this.name = name;
        this.calories = calories;
        this.carbohydrate = carbohydrate;
        this.protein = protein;
        this.fat = fat;
    }

    // Getters and Setters
    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getCalories() {
        return calories;
    }

    public void setCalories(double calories) {
        this.calories = calories;
    }

    public double getCarbohydrate() {
        return carbohydrate;
    }

    public void setCarbohydrate(double carbohydrate) {
        this.carbohydrate = carbohydrate;
    }

    public double getProtein() {
        return protein;
    }

    public void setProtein(double protein) {
        this.protein = protein;
    }

    public double getFat() {
        return fat;
    }

    public void setFat(double fat) {
        this.fat = fat;
    }

    @Override
    public String toString() {
        return "Food{" +
                "code=" + code +
                ", name='" + name + '\'' +
                ", calories=" + calories +
                ", carbohydrate=" + carbohydrate +
                ", protein=" + protein +
                ", fat=" + fat +
                '}';
    }
}
