package com.ssafy.exam.model.dao;

import com.ssafy.exam.model.dto.DietRecord;
import com.ssafy.exam.model.dto.Food;
import com.ssafy.exam.model.dto.User;

import java.util.List;

public interface CoachDao {

    // User 관련
    List<User> selectAllUsers();
    User selectUserById(String userId);
    void insertUser(User user);
    void updateUser(User user);
    void deleteUser(String userId);
    User login(String userId, String password);

    // Food 관련
    List<Food> selectAllFoods();
    Food selectFoodByCode(int foodCode);

    // DietRecord 관련
    List<DietRecord> selectAllDietRecords(String userId);
    DietRecord selectDietRecordById(int recordId);
    void insertDietRecord(DietRecord dietRecord);
    void updateDietRecord(DietRecord dietRecord);
    void deleteDietRecord(int recordId);
}
